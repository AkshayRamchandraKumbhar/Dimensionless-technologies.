# Create your models here.
from django.db import models


# Create your models here.

class Profile(models.Model):
    image_name = models.URLField(max_length=150)
    objects_detected = models.EmailField(blank=True)
    timestamp = models.DateTimeField(max_length=50)


