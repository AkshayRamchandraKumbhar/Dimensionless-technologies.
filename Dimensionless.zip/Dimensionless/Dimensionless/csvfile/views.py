import csv
# from typing import io
from django.http import JsonResponse
from django.shortcuts import render
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt

from .models import Profile

# Create your views here.
import pandas as pd

from .models import Profile


def index(request):
    global datas, Date_data
    if request.method == "POST":
        new_Csv = request.FILES['file']
        # print(new_Csv)
        data_set = new_Csv.read().decode('utf-8')
        df_in = pd.read_csv(request.FILES['file'].temporary_file_path())
        # print(df_in)
        print(type(df_in))
        for i in range(len(df_in)):
            _, created = Profile.objects.update_or_create(
                image_name=df_in.loc[i, "image_name"],
                objects_detected=df_in.loc[i, "objects_detected"],
                timestamp=df_in.loc[i, 'timestamp']

            )
        # Date_data = Profile.objects.filter(timestamp__range=["2021-09-28", "2023-01-31"])
    return render(request, 'index.html')


# """Code For Date Check
# Date_data = Profile.objects.filter(timestamp__range=["2021-09-28", "2023-01-31"])
# print(Date_data)

# {'data': Date_data}"""

@csrf_exempt
def Data_Display(request):
    global contexts, Date_data
    print("Data Display Function Call")
    if request.method == "POST":
        Start = request.POST.get('Start')
        End = request.POST.get('End')
        print(Start, End)

        Date_data = Profile.objects.all()
        # for data in Date_data:
        # context = {
        #     "data": Date_data,
        # }
        data = list(Profile.objects.values())
        Dict = dict({'data': data})
        print(Dict)
    # return JsonResponse(contexts, content_type="application/json", safe=False)
    return JsonResponse(Dict,safe=False)

def display(request):
    # import pandas as pd
    # from_id = list(Form.objects.values())
    #
    # data = pd.DataFrame(from_id)
    # for i in from_id:
    #     # print(i)
    #     ID = (i['auto_increment_id'])
    #     dict1 = dict({"ID": ID})
    #     # print(dict1)
    from .models import Profile
    data = list(Profile.objects.values())
    Dict = dict({'data': data})
    print(Dict)

    return JsonResponse(Dict, safe=False)
from .models import Profile
data = list(Profile.objects.values())
Dict = dict({'data': data})
print(Dict)
