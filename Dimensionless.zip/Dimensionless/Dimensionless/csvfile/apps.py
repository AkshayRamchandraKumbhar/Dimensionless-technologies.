from django.apps import AppConfig


class CsvfileConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'csvfile'
